// Généré par outils/generer-sw.mjs — ne pas modifier à la main.
const VERSION = 'amani-05b12ad7bac0a0ff';
const FICHIERS = ["./","assets/AssetManifest.bin","assets/AssetManifest.bin.json","assets/FontManifest.json","assets/NOTICES","assets/assets/fonts/Fraunces-600-italic.ttf","assets/assets/fonts/Fraunces-600-normal.ttf","assets/assets/fonts/Fraunces-700-normal.ttf","assets/assets/fonts/Fraunces-800-normal.ttf","assets/assets/fonts/Inter-400.ttf","assets/assets/fonts/Inter-500.ttf","assets/assets/fonts/Inter-600.ttf","assets/assets/fonts/Inter-700.ttf","assets/assets/fonts/PlusJakartaSans-600.ttf","assets/assets/fonts/PlusJakartaSans-700.ttf","assets/assets/fonts/PlusJakartaSans-800.ttf","assets/assets/images/logo_amani.png","assets/assets/images/logo_amani_192.png","assets/fonts/MaterialIcons-Regular.otf","assets/fonts/fallback/Roboto-Regular.ttf","assets/packages/cupertino_icons/assets/CupertinoIcons.ttf","assets/packages/material_ui/shaders/ink_sparkle.frag","assets/shaders/ink_sparkle.frag","assets/shaders/stretch_effect.frag","canvaskit/canvaskit.js","canvaskit/canvaskit.wasm","canvaskit/chromium/canvaskit.js","canvaskit/chromium/canvaskit.wasm","canvaskit/skwasm.js","canvaskit/skwasm.wasm","canvaskit/skwasm_heavy.js","canvaskit/skwasm_heavy.wasm","canvaskit/webparagraph/canvaskit.js","canvaskit/webparagraph/canvaskit.wasm","canvaskit/wimp.js","canvaskit/wimp.wasm","config.json","favicon.png","flutter.js","flutter_bootstrap.js","icones/Icon-192.png","icones/Icon-512.png","icones/Icon-maskable-192.png","icones/Icon-maskable-512.png","icones/apple-touch-icon.png","main.dart.js","manifest.json","version.json"];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(FICHIERS.map((f) => new Request(f, { cache: 'reload' })))));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const cle of await caches.keys()) if (cle !== VERSION) await caches.delete(cle);
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  // L'API (données, synchronisation) ne passe jamais par le cache.
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.includes('/api/')) return;
  // config.json (adresse du serveur) : réseau d'abord, copie locale si hors ligne.
  if (url.pathname.endsWith('/config.json')) {
    e.respondWith(fetch(e.request).then((r) => {
      const copie = r.clone();
      caches.open(VERSION).then((c) => c.put(new Request('config.json'), copie));
      return r;
    }).catch(() => caches.match('config.json', { ignoreSearch: true })));
    return;
  }
  // Pages : réseau d'abord (nouvelle version), copie locale si hors ligne.
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).catch(() => caches.match('./', { ignoreSearch: true })));
    return;
  }
  // Fichiers de l'application : copie locale d'abord (démarrage instantané).
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((r) => r || fetch(e.request)));
});
